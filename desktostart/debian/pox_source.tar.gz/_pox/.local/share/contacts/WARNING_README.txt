Important Warning!!!

Don't create or copy vCards inside this folder manually, they are managed by the Akonadi framework!
